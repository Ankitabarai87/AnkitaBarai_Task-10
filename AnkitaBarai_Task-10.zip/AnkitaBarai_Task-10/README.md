# 🧺 Laundry Service- Adding Animation to Hero Section- Task- 10

This project demonstrates a simple **CSS animation using keyframes** to move an element in a square path with scaling effect. 

---

## ✨ Features

- Smooth movement using `@keyframes`
- Element moves in a square path
- Scale effect applied at start and end
- Infinite looping animation
- Linear timing for consistent speed

---

## 🛠️ Technologies Used

- HTML5  
- CSS3   

---

## 🎯 Concepts Practiced

- `@keyframes` animation  
- `transform: translate()`  
- `transform: scale()`  
- `animation` property  
- `transition-delay`   

---

## ▶️ How to Run

1. Clone or download this repository  
2. Open `index.html` in your browser  

---

## 🎓 Purpose

This project is created to practice:
- CSS animations using keyframes  
- Combining multiple transform functions  
- Creating smooth and continuous motion  

---

## 👩‍💻 Author

Ankita Barai


